import { ollama, getChatModel } from "../services/ollama.js";
import { callMcpTool, getToolsForOllama } from "../mcp/client.js";
import { extractTextToolCalls } from "./toolCallParser.js";

const MAX_ROUNDS = 6;

// Agent loop:
// LLM sees tools -> chooses a tool -> JS executes it -> tool result goes
// back to LLM -> LLM can choose another tool or produce final answer.
export async function runAgent(userMessage) {
  const tools = await getToolsForOllama();
  const toolNames = tools.map((t) => t.function.name);

  const messages = [
    {
      role: "system",
      content: `
You are a web research assistant.

Available MCP tools:
- scrape_and_store: use when the user gives a public URL and wants it scraped/learned.
- search_knowledge: use when the user asks about information already stored in the local knowledge base.

Rules:
1. Never claim a page was scraped unless scrape_and_store succeeded.
2. Prefer search_knowledge for knowledge-base questions.
3. If evidence is missing, say the knowledge base does not contain enough information.
4. After a tool returns, write a normal sentence answer. Never answer with raw JSON.
5. Keep answers clear and beginner friendly.
      `.trim(),
    },
    { role: "user", content: userMessage },
  ];

  const steps = [];

  for (let round = 0; round < MAX_ROUNDS; round++) {
    const response = await ollama.chat({
      model: getChatModel(),
      messages,
      tools,
      stream: false,
    });

    const assistantMessage = response.message;

    // Normal path: the model filled the structured tool_calls field.
    let toolCalls = (assistantMessage.tool_calls || []).map((call) => ({
      name: call.function.name,
      arguments: call.function.arguments || {},
      viaTextFallback: false,
    }));

    // Fallback path: some models write the call as JSON text in `content`.
    if (toolCalls.length === 0) {
      toolCalls = extractTextToolCalls(assistantMessage.content, toolNames).map(
        (call) => ({ ...call, viaTextFallback: true })
      );
    }

    // No tool request at all = this is the final answer.
    if (toolCalls.length === 0) {
      messages.push(assistantMessage);
      return {
        answer: assistantMessage.content || "No answer returned.",
        steps,
      };
    }

    // Store the assistant turn in the history in the structured form,
    // so the model sees one consistent conversation on the next round.
    messages.push({
      role: "assistant",
      content: "",
      tool_calls: toolCalls.map((call) => ({
        function: { name: call.name, arguments: call.arguments },
      })),
    });

    for (const call of toolCalls) {
      steps.push({
        type: "tool_call",
        tool: call.name,
        args: call.arguments,
        viaTextFallback: call.viaTextFallback,
      });

      let toolResult;
      try {
        toolResult = await callMcpTool(call.name, call.arguments);
      } catch (error) {
        toolResult = { isError: true, text: `Tool failed: ${error.message}` };
      }

      steps.push({
        type: "tool_result",
        tool: call.name,
        result: toolResult.text,
        isError: toolResult.isError,
      });

      // The LLM needs the tool's observation before deciding the next step.
      messages.push({
        role: "tool",
        tool_name: call.name,
        content: toolResult.text,
      });
    }
  }

  return {
    answer:
      "The agent reached the maximum number of tool rounds. Please make the request more specific.",
    steps,
  };
}
