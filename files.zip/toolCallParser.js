// Some Ollama models (for example qwen2.5-coder) do not fill the structured
// `tool_calls` field. They write the tool call as plain JSON text inside
// `message.content` instead. This file recovers those calls so the agent
// loop can still run the tool.

// Scan the text and return every top-level {...} block as a string.
// A plain regex cannot do this safely, so we count braces by hand and
// ignore braces that sit inside quoted strings.
function findJsonObjects(text) {
  const found = [];
  let depth = 0;
  let start = -1;
  let inString = false;
  let escaped = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];

    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }

    if (ch === '"') {
      inString = true;
    } else if (ch === "{") {
      if (depth === 0) start = i;
      depth++;
    } else if (ch === "}" && depth > 0) {
      depth--;
      if (depth === 0) found.push(text.slice(start, i + 1));
    }
  }

  return found;
}

// Different models use different key names. Accept the common ones.
function normalizeCall(obj) {
  if (!obj || typeof obj !== "object") return null;

  const source = obj.function && typeof obj.function === "object" ? obj.function : obj;
  const name = source.name || source.tool || source.tool_name || source.action;
  let args = source.arguments ?? source.parameters ?? source.args ?? source.input ?? {};

  if (typeof name !== "string") return null;

  if (typeof args === "string") {
    try {
      args = JSON.parse(args);
    } catch {
      return null;
    }
  }
  if (typeof args !== "object" || args === null || Array.isArray(args)) return null;

  return { name, arguments: args };
}

// Returns an array of { name, arguments }.
// Only names that exist in `validNames` are accepted, so ordinary JSON that
// appears inside a normal answer is never mistaken for a tool call.
export function extractTextToolCalls(content, validNames) {
  if (!content || typeof content !== "string") return [];

  const text = content.replace(/```(?:json)?/gi, "").trim();
  const calls = [];

  for (const block of findJsonObjects(text)) {
    let parsed;
    try {
      parsed = JSON.parse(block);
    } catch {
      continue;
    }

    const call = normalizeCall(parsed);
    if (call && validNames.includes(call.name)) calls.push(call);
  }

  return calls;
}
