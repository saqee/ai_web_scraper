import { extractTextToolCalls } from "./toolCallParser.js";
import assert from "node:assert/strict";

const names = ["scrape_and_store", "search_knowledge"];

// 1. Exact text from the user's screenshot
let r = extractTextToolCalls('{"name": "search_knowledge", "arguments": {"query": "what is paraphrase", "topK": 1}}', names);
assert.deepEqual(r, [{ name: "search_knowledge", arguments: { query: "what is paraphrase", topK: 1 } }]);

r = extractTextToolCalls('{"name": "scrape_and_store", "arguments": {"url": "https://example.com"}}', names);
assert.equal(r[0].name, "scrape_and_store");
assert.equal(r[0].arguments.url, "https://example.com");

// 2. Wrapped in a markdown code fence with extra words around it
r = extractTextToolCalls('Sure!\n```json\n{"name":"search_knowledge","arguments":{"query":"x"}}\n```', names);
assert.equal(r.length, 1);

// 3. Other key names and arguments given as a string
r = extractTextToolCalls('{"tool":"search_knowledge","args":"{\\"query\\":\\"hi\\"}"}', names);
assert.deepEqual(r[0].arguments, { query: "hi" });

// 4. Braces inside a string value must not confuse the scanner
r = extractTextToolCalls('{"name":"search_knowledge","arguments":{"query":"what is {json} }"}}', names);
assert.equal(r[0].arguments.query, "what is {json} }");

// 5. Two calls in one reply
r = extractTextToolCalls('{"name":"scrape_and_store","arguments":{"url":"https://a.com"}} {"name":"search_knowledge","arguments":{"query":"q"}}', names);
assert.equal(r.length, 2);

// 6. Unknown tool name is ignored; normal answers and JSON data are ignored
assert.deepEqual(extractTextToolCalls('{"name":"delete_everything","arguments":{}}', names), []);
assert.deepEqual(extractTextToolCalls("Paraphrasing means rewriting text.", names), []);
assert.deepEqual(extractTextToolCalls('Example: {"color":"red"}', names), []);
assert.deepEqual(extractTextToolCalls("", names), []);
assert.deepEqual(extractTextToolCalls(null, names), []);
assert.deepEqual(extractTextToolCalls("{broken json", names), []);

console.log("All parser tests passed");
